from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import AuthenticationForm
from tinymce.widgets import TinyMCE
from .models import AtletaGrupoDivisao, Atleta,Edital,EdicaoEvento, EventoOriginal, Noticia, RepresentanteEsportivo, EdicaoEvento, Grupo, Modalidade, Divisao
from django.conf import settings
from django.utils import timezone
from datetime import date
from django.core.exceptions import ValidationError
import re


class AtletaGrupoDivisaoForm(forms.ModelForm):
    divisao = forms.ModelChoiceField(queryset=Divisao.objects.all(), required=True)

    class Meta:
        model = AtletaGrupoDivisao
        fields = ['atleta', 'grupo', 'divisao']

    def clean(self):
        cleaned_data = super().clean()
        atleta = cleaned_data.get('atleta')
        divisao = cleaned_data.get('divisao')
        
        # Verifica se o atleta já está inscrito em duas divisões
        if AtletaGrupoDivisao.objects.filter(atleta=atleta).count() >= 2:
            raise forms.ValidationError("O atleta já está inscrito em duas divisões.")
        
        # Verifica se a divisão já atingiu o limite máximo de atletas
        divisao_count = AtletaGrupoDivisao.objects.filter(divisao=divisao).count()
        if divisao_count >= divisao.maxAtleta:
            raise forms.ValidationError(f"A divisão {divisao} já atingiu o número máximo de atletas.")

        return cleaned_data

class AtletaForm(forms.ModelForm):
    nascimento = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date'}),
        input_formats=settings.DATE_INPUT_FORMATS
    )

    class Meta:
        model = Atleta
        fields = ['nome', 'nascimento', 'rg', 'cpf', 'comprovante_matricula']

    def __init__(self, *args, grupo=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.grupo = grupo   # Recebe o grupo como parâmetro



    def clean_cpf(self):
        cpf = self.cleaned_data.get('cpf')
        if not validar_cpf(cpf):  
            raise ValidationError("CPF inválido.")
        return cpf

    def clean_rg(self):
        rg = self.cleaned_data.get('rg')
        if not validar_rg(rg):  
            raise ValidationError("RG inválido.")
        return rg
    def clean_nascimento(self):
        nascimento = self.cleaned_data.get('nascimento')
        if not self.grupo:
            raise ValidationError("Grupo não especificado para validação de idade.")

        # Calcular a idade do atleta
        hoje = date.today()
        idade = hoje.year - nascimento.year - ((hoje.month, hoje.day) < (nascimento.month, nascimento.day))

        # Verificar idade mínima
        if self.grupo.idade_minima and idade < self.grupo.idade_minima:
            raise ValidationError(f"A idade mínima para este grupo é {self.grupo.idade_minima} anos.")

        # Verificar idade máxima
        if self.grupo.idade_maxima and idade > self.grupo.idade_maxima:
            raise ValidationError(f"A idade máxima para este grupo é {self.grupo.idade_maxima} anos.")

        return nascimento

class EditalForm(forms.ModelForm):
    class Meta:
        model = Edital
        fields = ['arquivo']

    def clean_arquivo(self):
        arquivo = self.cleaned_data.get('arquivo')
        if not arquivo.name.endswith('.pdf'):
            raise forms.ValidationError("O arquivo deve ser um PDF.")
        return arquivo
    
class DivisaoForm(forms.ModelForm):
    grupo_id = forms.IntegerField(widget=forms.HiddenInput(), required=False)  # Campo oculto para o grupo

    class Meta:
        model = Divisao
        fields = ['tipo_divisao', 'minAtleta', 'maxAtleta', 'modalidade']

    def __init__(self, *args, **kwargs):
        grupo_id = kwargs.pop('grupo_id', None)  # Obtém o grupo_id da view
        super().__init__(*args, **kwargs)

        if grupo_id:
            self.fields['grupo_id'].initial = grupo_id  # Preenche o campo oculto com o grupo_id

    def clean(self):
        cleaned_data = super().clean()

        min_atleta = cleaned_data.get('minAtleta')
        max_atleta = cleaned_data.get('maxAtleta')

        # Verifica se o número máximo de atletas é maior que o mínimo
        if min_atleta is not None and max_atleta is not None:
            if max_atleta <= min_atleta:
                self.add_error('maxAtleta', "O número máximo de atletas deve ser maior que o número mínimo.")

        return cleaned_data

    def save(self, commit=True):
        divisao = super().save(commit=False)

        # Obtém o grupo a partir do grupo_id oculto
        grupo_id = self.cleaned_data.get('grupo_id')
        if grupo_id:
            try:
                grupo = Grupo.objects.get(id=grupo_id)
                divisao.grupo = grupo
            except Grupo.DoesNotExist:
                raise forms.ValidationError("O grupo associado não foi encontrado.")

        if commit:
            divisao.save()

        return divisao

    


class ModalidadeForm(forms.ModelForm):
    class Meta:
        model = Modalidade
        fields = ['nome', 'regras_modalidade', 'local', 'categoria']

        def clean(self):
            nome = self.cleaned_data.get('nome')
            return nome.upper() if nome else nome
class EventoOriginalForm(forms.ModelForm):
    class Meta:
        model = EventoOriginal
        fields = ['nome']

class EdicaoEventoForm(forms.ModelForm):
    
    evento_original = forms.ModelChoiceField(
        queryset=EventoOriginal.objects.all(),
        empty_label="Escolha um evento original ou crie um novo",
        required=False
    )
    novo_evento_original = forms.CharField(
        max_length=100,
        required=False,
        label="Criar novo evento original"
    )
    data_inicio = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date'}),
        input_formats=settings.DATE_INPUT_FORMATS
    )
    data_fim = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date'}),
        input_formats=settings.DATE_INPUT_FORMATS
    )
    data_fim_inscricao = forms.DateField(
        label="Data final para inscrição:",
        widget=forms.DateInput(attrs={'type': 'date'}),
        input_formats=settings.DATE_INPUT_FORMATS
    )
    
    class Meta:
        model = EdicaoEvento
        fields = ['edicao', 'local', 'descricao', 'cidade', 'data_inicio', 'data_fim', 'data_fim_inscricao']

    def clean(self):
        cleaned_data = super().clean()
        data_fim_inscricao = cleaned_data.get('data_fim_inscricao')
        data_inicio = cleaned_data.get('data_inicio')
        data_fim = cleaned_data.get('data_fim')

        # Validação geral para o campo 'data_fim_inscricao'
        if not data_fim_inscricao:
            self.add_error('data_fim_inscricao', "O campo 'Data final para inscrição' é obrigatório.")
            return cleaned_data

        # Verificação de relação entre as datas
        if data_inicio and data_fim_inscricao and data_fim:
            if data_inicio >= data_fim_inscricao:
                self.add_error('data_fim_inscricao', "A data final de inscrição não pode ser anterior à data de início.")
            if data_fim_inscricao >= data_fim:
                self.add_error('data_fim_inscricao', "A data final de inscrição não pode ser posterior à data final do evento.")

        return cleaned_data


class GrupoForm(forms.ModelForm):
    taxa = forms.DecimalField(
        label="Taxa (R$)",
        max_digits=10,
        decimal_places=2,
        localize=True
    )
    class Meta:
        
        model = Grupo
        fields = ['nome', 'descricao_grupo', 'taxa', 'idade_minima', 'idade_maxima']
    def clean_nome(self):
        nome = self.cleaned_data.get('nome')

        # Converte o nome para maiúsculas
        nome_upper = nome.upper()
        return nome_upper

    # Sobrescrevendo o método clean() para garantir que o nome seja armazenado em maiúsculas
    def clean(self):
        cleaned_data = super().clean()
        nome = cleaned_data.get('nome')

        if nome:
            # Converte o nome para maiúsculas
            cleaned_data['nome'] = nome.upper()

        return cleaned_data
        
def validar_cpf(cpf):
    cpf = ''.join([char for char in cpf if char.isdigit()])  
    if len(cpf) != 11:
        return False

    if cpf in [s * 11 for s in "0123456789"]:
        return False  
    soma = sum(int(cpf[i]) * (10 - i) for i in range(9))
    primeiro_verificador = (soma * 10 % 11) % 10
    if primeiro_verificador != int(cpf[9]):
        return False
    
    soma = sum(int(cpf[i]) * (11 - i) for i in range(10))
    segundo_verificador = (soma * 10 % 11) % 10
    if segundo_verificador != int(cpf[10]):
        return False

    return True

class RepresentanteRegistroForm(forms.ModelForm):
    username = forms.CharField(label="CPF", max_length=11)
    password = forms.CharField(label="Senha", widget=forms.PasswordInput)
    password_confirm = forms.CharField(label="Confirme a Senha", widget=forms.PasswordInput)

    class Meta:
        model = RepresentanteEsportivo
        fields = ['nome', 'representacao', 'telefone', 'email', 'documento', 'rg', 'dados_escola']  # Removendo 'cpf'

    def clean_username(self):
        cpf = self.cleaned_data.get('username')
        if not validar_cpf(cpf):  # Certifique-se de que validar_cpf está implementado
            raise forms.ValidationError("CPF inválido.")
        if User.objects.filter(username=cpf).exists():
            raise forms.ValidationError("CPF já cadastrado.")
        return cpf

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get("password")
        password_confirm = cleaned_data.get("password_confirm")

        if password != password_confirm:
            raise forms.ValidationError("As senhas são diferentes.")

        return cleaned_data

    def save(self, commit=True):
        # Criação do usuário com CPF como username
        user = User.objects.create_user(
            username=self.cleaned_data['username'],  # Utilizando o CPF como username
            email=self.cleaned_data['email'],
            password=self.cleaned_data['password']
        )

        # Criar instância de RepresentanteEsportivo
        representante = super().save(commit=False)
        representante.user = user  # Associando o usuário ao representante
        representante.cpf = self.cleaned_data['username']  # Salvando o CPF no modelo RepresentanteEsportivo
        
        if commit:
            representante.save()  # Salva o representante
        
        return representante


class RepresentanteLoginForm(AuthenticationForm):
    username = forms.CharField(label="CPF", max_length=11)
    password = forms.CharField(label="Senha", widget=forms.PasswordInput)



class NoticiaForm(forms.ModelForm):
    data_fim = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date'}),
        input_formats=settings.DATE_INPUT_FORMATS
    )

    class Meta:
        model = Noticia
        fields = ['titulo', 'texto', 'imagem', 'data_fim']
        widgets = {
            'texto': TinyMCE(attrs={'cols': 80, 'rows': 30}),
        }
    
    def clean(self):
        cleaned_data = super().clean()
        data_fim = cleaned_data.get('data_fim')
        if data_fim < timezone.now().date():
            raise forms.ValidationError("A data de expiração da noticia deve ser hoje ou uma data futura.")
        

def validar_rg(rg):
    """
    Valida o formato de um RG.
    
    Regras:
    - O RG deve conter entre 7 e 9 dígitos.
    - Pode incluir pontos e hífen (serão ignorados na validação).
    - Não pode ser vazio ou conter apenas caracteres não numéricos.
    
    :param rg: String representando o RG.
    :return: True se o RG for válido, False caso contrário.
    """
    if not rg:
        return False

    # Remove pontos, hífens e espaços
    rg_limpo = re.sub(r'[^\d]', '', rg)

    # Verifica se o RG limpo tem entre 7 e 9 dígitos
    if len(rg_limpo) < 7 or len(rg_limpo) > 9:
        return False

    # Verifica se o RG contém apenas números
    if not rg_limpo.isdigit():
        return False

    return True