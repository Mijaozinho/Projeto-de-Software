from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.models import Group
from django.contrib.auth.decorators import login_required
from django.http import FileResponse, HttpResponseRedirect
from .forms import AtletaForm,  RepresentanteLoginForm, RepresentanteRegistroForm, NoticiaForm, EditalForm,EdicaoEventoForm, GrupoForm, ModalidadeForm, DivisaoForm
from .models import PagamentoGrupo,Noticia, EdicaoEvento, Grupo, EventoOriginal, Modalidade, Divisao, AtletaGrupoDivisao, RepresentanteEsportivo, Atleta
import logging
import os
from django.conf import settings
from django.contrib import messages
from django.utils import timezone
import shutil
from django.db.models import Count
from datetime import timedelta, datetime
from .utils.gerar_cobranca_pix import pagar_pix
from .utils.verifica_pagamento import verifica_status
from reportlab.pdfgen import canvas
import csv
from django.http import HttpResponse
import csv
from django.shortcuts import get_object_or_404
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch

def gerar_pdf(request, evento_id, grupo_id):
    grupo = get_object_or_404(Grupo, id=grupo_id)
    evento = get_object_or_404(EdicaoEvento, id=evento_id)
    
    representantes = RepresentanteEsportivo.objects.filter(
        id__in=AtletaGrupoDivisao.objects.filter(grupo_id=grupo_id).values_list('representante_esportivo', flat=True)
    ).distinct()

    pagamentos = PagamentoGrupo.objects.filter(grupo=grupo)
    status_pagamento = []
    representantes_concluidos = []

    for representante in representantes:
        pagamento = pagamentos.filter(representante_esportivo=representante).first()
        status = verifica_status(pagamento.id_pix) if pagamento else 'NÃO GERADO'
        if status == "CONCLUIDA":
            representantes_concluidos.append(representante)
            status_pagamento.append({
                'representacao': representante.representacao,
                'status': status
            })

    response = HttpResponse(content_type="application/pdf")
    response['Content-Disposition'] = f'attachment; filename="divisoes_{grupo.nome}.pdf"'

    doc = SimpleDocTemplate(response, pagesize=A4)
    styles = getSampleStyleSheet()
    elements = []

    elements.append(Paragraph(f"<b>Grupo:</b> {grupo.nome}", styles['Title']))
    elements.append(Paragraph(f"<b>Taxa:</b> R$ {grupo.taxa:.2f}", styles['Normal']))
    elements.append(Spacer(1, 0.2 * inch))

    elements.append(Paragraph("<b>Lista das Modalidades:</b>", styles['Heading2']))
    divisao_header = ['Modalidade', 'Mín. Atletas', 'Máx. Atletas', 'Tipo da Divisão']
    divisao_data = [
        [divisao.modalidade.nome, divisao.minAtleta, divisao.maxAtleta, divisao.get_tipo_divisao_display()]
        for divisao in Divisao.objects.filter(grupo=grupo)
    ]

    if divisao_data:
        tabela_divisoes = Table([divisao_header] + divisao_data, hAlign='CENTER')
        tabela_divisoes.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ]))
        elements.append(tabela_divisoes)
    else:
        elements.append(Paragraph("Nenhuma divisão encontrada para este grupo.", styles['Normal']))

    elements.append(Spacer(1, 0.2 * inch))

    modalidades = Modalidade.objects.filter(edicao_evento=evento)

    for modalidade in modalidades:
        elements.append(Paragraph(f"<b>Modalidade:</b> {modalidade.nome}", styles['Heading2']))
        atletas_data = [['Representação', 'Nome Atleta', 'Data Nascimento']]
        atletas = AtletaGrupoDivisao.objects.filter(
            divisao__modalidade=modalidade,
            representante_esportivo__in=[r.id for r in representantes_concluidos]
        )

        for atleta in atletas:
            atletas_data.append([
                atleta.representante_esportivo.representacao,
                atleta.atleta.nome,
                atleta.atleta.nascimento.strftime('%d/%m/%Y')
            ])

        if len(atletas_data) > 1:
            tabela_atletas = Table(atletas_data, hAlign='CENTER')
            tabela_atletas.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ]))
            elements.append(tabela_atletas)
        else:
            elements.append(Paragraph("Nenhuma inscrição paga encontrada.", styles['Normal']))

        elements.append(Spacer(1, 0.2 * inch))

    doc.build(elements)

    return response



def gerar_csv(request, evento_id, grupo_id):
    grupo = get_object_or_404(Grupo, id=grupo_id)
    evento = get_object_or_404(EdicaoEvento, id=evento_id)

    representantes = RepresentanteEsportivo.objects.filter(
        id__in=AtletaGrupoDivisao.objects.filter(grupo_id=grupo_id).values_list('representante_esportivo', flat=True)
    ).distinct()

    pagamentos = PagamentoGrupo.objects.filter(grupo=grupo)
    representantes_concluidos = []

    for representante in representantes:
        pagamento = pagamentos.filter(representante_esportivo=representante).first()
        status = verifica_status(pagamento.id_pix) if pagamento else 'NÃO GERADO'
        if status == "CONCLUIDA":
            representantes_concluidos.append(representante)

    response = HttpResponse(content_type="text/csv")
    response['Content-Disposition'] = f'attachment; filename="divisoes_{grupo.nome}.csv"'

    writer = csv.writer(response, delimiter=';')

    divisoes = Divisao.objects.filter(grupo=grupo)

    for divisao in divisoes:
        writer.writerow([f'Divisão: {divisao.modalidade.nome} - {divisao.get_tipo_divisao_display()}'])
        writer.writerow(['Modalidade', 'Divisão', 'Nome Atleta', 'Data Nascimento', 'CPF', 'Representante'])

        atletas = AtletaGrupoDivisao.objects.filter(
            divisao=divisao, representante_esportivo__in=[r.id for r in representantes_concluidos]
        )
        for atleta in atletas:
            writer.writerow([
                divisao.modalidade.nome,
                divisao.get_tipo_divisao_display(),
                atleta.atleta.nome,
                atleta.atleta.nascimento.strftime('%d/%m/%Y'),
                atleta.atleta.cpf,
                atleta.representante_esportivo.nome
            ])

        writer.writerow([])

    return response


@login_required(login_url="login")
def processar_pagamento(request, id_grupo, nome, cpf, id_evento):
    try:
        grupo = Grupo.objects.get(id=id_grupo)
        evento = EdicaoEvento.objects.get(id=id_evento)
        representante = RepresentanteEsportivo.objects.get(cpf=cpf, nome=nome)


        pagamento_existente = PagamentoGrupo.objects.filter(
            grupo=grupo,
            representante_esportivo=representante
        ).first()

        if pagamento_existente:
            
            print("Pagamento já gerado anteriormente.")
            return HttpResponseRedirect(pagamento_existente.link_pix)

        print(f"Grupo: {grupo}")
        print(f"Evento: {evento}")
        print(f"Representante: {representante}")

        atletas_unicos = Atleta.objects.filter(
            atletagrupodivisao__grupo=grupo,
            atletagrupodivisao__representante_esportivo=representante
        ).distinct()
        
        numero_atletas = atletas_unicos.count()

        print(f"Atletas associados ao representante no grupo: {numero_atletas}")

        taxa = grupo.taxa 
        print(f"Taxa do grupo: {taxa}")

      
        data_final = evento.data_fim_inscricao + timedelta(days=7)
        print(f"Data final para pagamento: {data_final}")

        nome= representante.nome

        link_pix, id_pix = pagar_pix(data_final.strftime('%d/%m/%y'), float(taxa), int(numero_atletas), str(cpf), str(nome))
        print(f"Link do Pix gerado: {link_pix}")

        pagamento_grupo = PagamentoGrupo.objects.create(
            grupo=grupo,
            representante_esportivo=representante,
            link_pix=link_pix,
            id_pix=id_pix
        )

        return HttpResponseRedirect(link_pix)


    except Grupo.DoesNotExist:
        print(f"Erro: Grupo com id {id_grupo} não encontrado.")
        return render(request, 'html/home.html', {'error': 'Grupo não encontrado.'})
    except EdicaoEvento.DoesNotExist:
        print(f"Erro: Evento com id {id_evento} não encontrado.")
        return render(request, 'html/home.html', {'error': 'Evento não encontrado.'})
    except RepresentanteEsportivo.DoesNotExist:
        print(f"Erro: Representante esportivo com CPF {cpf} e nome {nome} não encontrado.")
        return render(request, 'html/home.html', {'error': 'Representante esportivo não encontrado.'})
    except Exception as e:
        print(f"Erro inesperado: {str(e)}")
        return render(request, 'html/home.html', {'error': str(e)})


@login_required(login_url="login")
def listar_atletas(request, evento_id, grupo_id, divisao_id, equipe_id):
    if not is_admin_esportivo(request.user):
            return redirect('user')

    grupo = get_object_or_404(Grupo, id=grupo_id)
    divisao = get_object_or_404(Divisao, id=divisao_id)
    
    representacao= get_object_or_404(RepresentanteEsportivo, id=equipe_id)
    atletas = AtletaGrupoDivisao.objects.filter(
        grupo=grupo, divisao=divisao, representante_esportivo=representacao
    ).distinct()
    return render(request, 'html/listar_atletas.html', {
        'grupo': grupo,
        'divisao': divisao,
        'atletas': atletas,
        'representacao':representacao
    })

@login_required(login_url="login")
def divisao_adm(request, evento_id, grupo_id, divisao_id):
    if not is_admin_esportivo(request.user):
        return redirect('user')
    
    evento = get_object_or_404(EdicaoEvento, id=evento_id)
    grupo = get_object_or_404(Grupo, id=grupo_id)
    divisao = get_object_or_404(Divisao, id=divisao_id)
    
    data_hoje = timezone.now().date()

    representacoes = RepresentanteEsportivo.objects.filter(
        atletagrupodivisao__grupo=grupo,
        atletagrupodivisao__divisao=divisao
    ).distinct()

    return render(request, 'html/divisao_adm.html', {
        'evento': evento,
        'grupo': grupo,
        'divisao': divisao,
        'representacoes': representacoes,
        'data_hoje': data_hoje
    })

@login_required(login_url="login")
def excluir_representacoes_selecionadas(request, evento_id, grupo_id, divisao_id):
    if not is_admin_esportivo(request.user):
        return redirect('user')
    
    evento = get_object_or_404(EdicaoEvento, id=evento_id)
    grupo = get_object_or_404(Grupo, id=grupo_id)
    divisao = get_object_or_404(Divisao, id=divisao_id)

    if request.method == "POST":
        representacoes_ids = request.POST.getlist('representacoes_selecionadas')

        if representacoes_ids:
            AtletaGrupoDivisao.objects.filter(
                grupo=grupo,
                divisao=divisao,
                representante_esportivo__id__in=representacoes_ids
            ).delete()

            messages.success(request, "Representações selecionadas foram excluídas com sucesso.")
        else:
            messages.warning(request, "Nenhuma representação foi selecionada para exclusão.")

    return redirect('divisao_adm', evento_id=evento.id, grupo_id=grupo.id, divisao_id=divisao.id)


@login_required(login_url="login")
def inscrever_divisoes(request, evento_id, grupo_id):
    if is_admin_esportivo(request.user):
        return redirect('adm')
    grupo = get_object_or_404(Grupo, id=grupo_id)
    evento = get_object_or_404(EdicaoEvento, id=evento_id)

    try:
        representante = RepresentanteEsportivo.objects.get(user=request.user)
    except RepresentanteEsportivo.DoesNotExist:
        messages.error(request, "Você não tem permissão para acessar essa página.")
        return redirect('home')

    divisoes = Divisao.objects.filter(grupo=grupo)
    
    for divisao in divisoes:
        divisao.inscrito = divisao.atletagrupodivisao_set.filter(representante_esportivo=representante).exists()

    return render(request, 'html/inscrever_divisoes.html', {
        'grupo': grupo,
        'evento': evento,
        'divisoes': divisoes,
        'representante': representante,
    })


@login_required(login_url="login")
def divisao_page(request, evento_id, grupo_id, divisao_id):
    if is_admin_esportivo(request.user):
        return redirect('adm')
    grupo = get_object_or_404(Grupo, id=grupo_id)
    evento = get_object_or_404(EdicaoEvento, id=evento_id)
    divisao = get_object_or_404(Divisao, id=divisao_id)
    representante = get_object_or_404(RepresentanteEsportivo, user=request.user)

    atletas_inscritos = Atleta.objects.filter(
        atletagrupodivisao__grupo=grupo,
        atletagrupodivisao__divisao=divisao,
        atletagrupodivisao__representante_esportivo=representante
    ).distinct()

    atletas_nao_inscritos = Atleta.objects.filter(
        atletagrupodivisao__grupo=grupo,
        atletagrupodivisao__representante_esportivo=representante
    ).exclude(id__in=atletas_inscritos.values_list('id', flat=True)).distinct()

    if request.method == "POST":
        action = request.POST.get('action')

        if action == 'delete':
            atleta_ids = request.POST.getlist('atletas')
            AtletaGrupoDivisao.objects.filter(
                divisao=divisao,
                atleta__id__in=atleta_ids,
                grupo=grupo,
                representante_esportivo=representante
            ).delete()
            messages.success(request, 'Atletas removidos da divisão com sucesso.')
        
        elif action == 'clear_division':
            AtletaGrupoDivisao.objects.filter(
                divisao=divisao,
                grupo=grupo,
                representante_esportivo=representante
            ).delete()
            messages.success(request, 'Todos os atletas foram removidos e a inscrição na divisão foi desfeita.')
        
        elif action == 'add':
            atleta_ids = request.POST.getlist('atletas')
            for atleta_id in atleta_ids:
                atleta = get_object_or_404(Atleta, id=atleta_id)
                AtletaGrupoDivisao.objects.get_or_create(
                    atleta=atleta,
                    grupo=grupo,
                    divisao=divisao,
                    representante_esportivo=representante
                )
            messages.success(request, 'Atletas adicionados à divisão com sucesso.')

        return redirect('divisao_page', evento_id=evento.id, grupo_id=grupo.id, divisao_id=divisao.id)

    return render(request, 'html/divisao_page.html', {
        'divisao': divisao,
        'evento': evento,
        'grupo': grupo,
        'atletas_inscritos': atletas_inscritos,
        'atletas_nao_inscritos': atletas_nao_inscritos,
    })




@login_required(login_url="login")
def inscricao(request, evento_id, grupo_id):
    if is_admin_esportivo(request.user):
        return redirect('adm')    
    grupo = get_object_or_404(Grupo, id=grupo_id)
    evento = get_object_or_404(EdicaoEvento, id=evento_id)
    representante = get_object_or_404(RepresentanteEsportivo, user=request.user)
    
    data_hoje = timezone.now().date()
    divisoes = Divisao.objects.filter(grupo=grupo)
    
    atletas = Atleta.objects.filter(
        atletagrupodivisao__grupo=grupo,
        atletagrupodivisao__representante_esportivo=representante
    ).annotate(divisoes_count=Count('atletagrupodivisao__divisao')).distinct()

    atleta_form = AtletaForm(request.POST or None, request.FILES or None, grupo=grupo)
    
    if request.method == "POST":
        if 'action' in request.POST and request.POST['action'] == 'delete':
            atleta_ids = request.POST.getlist('atletas')
            atletas_para_apagar = Atleta.objects.filter(id__in=atleta_ids)
            if atletas_para_apagar.exists():
                atletas_para_apagar.delete()
                messages.success(request, 'Atletas excluídos com sucesso!')
            else:
                messages.error(request, 'Nenhum atleta selecionado ou encontrado para exclusão.')
            return redirect('inscricao', grupo_id=grupo.id, evento_id=evento.id)

        elif atleta_form.is_valid():
            novo_atleta = atleta_form.save(commit=False)
            novo_atleta.save()
            
            if not AtletaGrupoDivisao.objects.filter(
                atleta=novo_atleta, grupo=grupo, representante_esportivo=representante
            ).exists():
                AtletaGrupoDivisao.objects.create(
                    atleta=novo_atleta,
                    grupo=grupo,
                    representante_esportivo=representante
                )
            else:
                messages.warning(request, "Este atleta já está inscrito neste grupo.")
            return redirect('inscricao', evento_id=evento.id, grupo_id=grupo.id)

    return render(request, 'html/inscricao.html', {
        'grupo': grupo,
        'evento': evento,
        'atletas': atletas,
        'atleta_form': atleta_form,
        'divisoes': divisoes,
        'data_hoje':data_hoje
    })


@login_required(login_url='login')
def evento_detalhes(request, evento_id):
    if not is_admin_esportivo(request.user):
        return redirect('home')
    
    evento = get_object_or_404(EdicaoEvento, id=evento_id)
    grupos = Grupo.objects.filter(edicao_evento=evento)
    modalidades = Modalidade.objects.filter(edicao_evento=evento)
    
    data_hoje = timezone.now().date()
    grupo_form = GrupoForm()
    modalidade_form = ModalidadeForm()

    if request.method == 'POST':
        if 'add_grupo' in request.POST:
            grupo_form = GrupoForm(request.POST)
            if grupo_form.is_valid():
                nome_grupo = grupo_form.cleaned_data['nome']
                if Grupo.objects.filter(nome=nome_grupo, edicao_evento= evento).exists():
                    print(evento)
                    messages.error(request, "Já existe um grupo com este nome nesta edição do evento.")
                else:
                    grupo = grupo_form.save(commit=False)
                    grupo.edicao_evento = evento
                    grupo.save()
                    messages.success(request, "Grupo adicionado com sucesso!")
                return redirect('detalhes_evento', evento_id=evento_id)
        
        
        elif 'delete_grupo' in request.POST:
            grupo_id = request.POST.get('grupo_id')
            grupo = get_object_or_404(Grupo, id=grupo_id)
            grupo.delete()
            messages.success(request, "Grupo removido com sucesso!")
            return redirect('detalhes_evento', evento_id=evento_id)
        
        elif 'add_modalidade' in request.POST:
            modalidade_form = ModalidadeForm(request.POST)
            if modalidade_form.is_valid():
                nome_modalidade = modalidade_form.cleaned_data['nome']
                if Modalidade.objects.filter(edicao_evento=evento, nome=nome_modalidade).exists():
                    messages.error(request, "Já existe uma modalidade com este nome nesta edição do evento.")
                else:
                    modalidade = modalidade_form.save(commit=False)
                    modalidade.edicao_evento = evento
                    modalidade.save()
                    messages.success(request, "Modalidade adicionada com sucesso!")
                return redirect('detalhes_evento', evento_id=evento_id)
        
        elif 'edit_modalidade' in request.POST:
            modalidade_id = request.POST.get('modalidade_id')
            modalidade = get_object_or_404(Modalidade, id=modalidade_id)
            modalidade_form = ModalidadeForm(request.POST, instance=modalidade)
            if modalidade_form.is_valid():
                nome_modalidade = modalidade_form.cleaned_data['nome']
                if Modalidade.objects.filter(edicao_evento=evento, nome=nome_modalidade).exclude(id=modalidade_id).exists():
                    messages.error(request, "Já existe uma modalidade com este nome nesta edição do evento.")
                else:
                    modalidade_form.save()
                    messages.success(request, "Modalidade editada com sucesso!")
                return redirect('detalhes_evento', evento_id=evento_id)
        
        elif 'delete_modalidade' in request.POST:
            modalidade_id = request.POST.get('modalidade_id')
            modalidade = get_object_or_404(Modalidade, id=modalidade_id)
            modalidade.delete()
            messages.success(request, "Modalidade removida com sucesso!")
            return redirect('detalhes_evento', evento_id=evento_id)

        elif 'delete_evento' in request.POST:
            evento.delete()
            evento_folder = os.path.join(settings.MEDIA_ROOT, 'eventos', str(evento.edicao))
            if os.path.exists(evento_folder) and os.path.isdir(evento_folder):
                shutil.rmtree(evento_folder)
            return redirect('adm')
        
        elif 'action' in request.POST and request.POST['action'] == 'delete':
            grupo_ids = request.POST.getlist('grupos')
            if grupo_ids:
                grupos_a_excluir = Grupo.objects.filter(id__in=grupo_ids, edicao_evento=evento)
                grupos_a_excluir.delete()
                messages.success(request, "Grupos selecionados foram excluídos com sucesso!")
            else:
                messages.warning(request, "Nenhum grupo foi selecionado para exclusão.")
            return redirect('detalhes_evento', evento_id=evento_id)
        
    context = {
        'evento': evento,
        'grupos': grupos,
        'modalidades': modalidades,
        'grupo_form': grupo_form,
        'modalidade_form': modalidade_form,
        'data_hoje': data_hoje
    }

    return render(request, 'html/detalhes_evento.html', context)



@login_required(login_url="login")
def excluir_evento(request, evento_id):
    if not is_admin_esportivo(request.user):
        return redirect('user')
    
    evento = get_object_or_404(EdicaoEvento, id=evento_id)

    if request.method == 'POST':
        if 'confirmar' in request.POST and request.POST['confirmar'] == 'sim':
            evento.delete()

            evento_folder = os.path.join(settings.MEDIA_ROOT, 'eventos', str(evento.edicao))
            if os.path.exists(evento_folder) and os.path.isdir(evento_folder):
                shutil.rmtree(evento_folder)

            return redirect('adm')

        return redirect('adm')

    return render(request, 'html/excluir_evento.html', {'evento': evento})

@login_required(login_url='login')
def detalhes_user(request, grupo_id, evento_id):
    if  is_admin_esportivo(request.user):
        return redirect('adm')
    evento = get_object_or_404(EdicaoEvento, id=evento_id)
    grupo = get_object_or_404(Grupo, id=grupo_id)
    divisoes = Divisao.objects.filter(grupo=grupo)
    data_hoje = timezone.now().date()
    data_final_inscricao = evento.data_fim_inscricao
    data_pagamento = data_final_inscricao + timedelta(weeks=1)
    representante = RepresentanteEsportivo.objects.get(user=request.user)

    pagamento_existente = PagamentoGrupo.objects.filter(grupo=grupo, representante_esportivo=representante).first()
    pagamento_status = verifica_status(pagamento_existente.id_pix) if pagamento_existente else None
    pagamento_link = pagamento_existente.link_pix if pagamento_existente else None

    context = {
        'evento': evento,
        'grupo': grupo,
        'divisoes': divisoes,
        'data_hoje': data_hoje,
        'data_pagamento': data_pagamento,
        'representante': representante,
        'pagamento_status': pagamento_status,
        'pagamento_link': pagamento_link
    }
    return render(request, 'html/grupo_user.html', context)
    
@login_required(login_url='login')
def upload_edital(request, evento_id):
    if not is_admin_esportivo(request.user):
        return redirect('home')
    
    evento = get_object_or_404(EdicaoEvento, id=evento_id)

    if request.method == 'POST':
        form = EditalForm(request.POST, request.FILES)
        if form.is_valid():
            edital = form.save(commit=False)
            edital.evento = evento  
            edital.save()
            return redirect('editais')  
    else:
        form = EditalForm()

    context = {
        'form': form,
        'evento': evento
    }
    
    return render(request, 'html/upload_edital.html', context)

@login_required(login_url='login')
def detalhes_grupo(request, grupo_id, evento_id):
    if not is_admin_esportivo(request.user):
        logout(request)
        return redirect('home')
    
    evento = get_object_or_404(EdicaoEvento, id=evento_id)
    grupo = get_object_or_404(Grupo, id=grupo_id)

    divisoes_do_grupo = Divisao.objects.filter(grupo=grupo)

    modalidades = Modalidade.objects.filter(edicao_evento=evento)

    pagamentos = PagamentoGrupo.objects.filter(grupo=grupo)
    representantes = RepresentanteEsportivo.objects.filter(
        id__in=AtletaGrupoDivisao.objects.filter(grupo_id=grupo_id).values_list('representante_esportivo', flat=True)
    ).distinct()

    status_pagamento = []
    for representante in representantes:
        pagamento = pagamentos.filter(representante_esportivo=representante).first()
        status_pagamento.append({
            'representacao': representante.representacao,
            'status': verifica_status(pagamento.id_pix) if pagamento else 'NÃO GERADO'
        })
    
    return render(request, 'html/detalhes_grupo.html', {
        'grupo': grupo,
        'divisoes_do_grupo': divisoes_do_grupo,  
        'evento': evento,
        'modalidades': modalidades,
        'status_pagamento': status_pagamento
    })


@login_required(login_url='login')
def editar_divisoes(request, grupo_id, evento_id):
    if not is_admin_esportivo(request.user):
        logout(request)
        return redirect('home')
    
    
    data_hoje = timezone.now().date()
    evento = get_object_or_404(EdicaoEvento, id=evento_id)
    grupo = get_object_or_404(Grupo, id=grupo_id)

    modalidades = Modalidade.objects.filter(edicao_evento=evento)
    divisoes = Divisao.objects.filter(grupo=grupo)

    divisao_form = DivisaoForm(grupo_id=grupo.id)

    if request.method == 'POST':
        if 'action' in request.POST and request.POST['action'] == 'delete':
            divisao_ids = request.POST.getlist('divisoes')  

            if divisao_ids:
                divisoes_para_apagar = Divisao.objects.filter(id__in=divisao_ids)
                divisoes_para_apagar.delete()
                messages.success(request, 'Divisões excluídas com sucesso!')
            else:
                messages.error(request, 'Nenhuma divisão selecionada para exclusão.')

            return redirect('editar_divisoes', grupo_id=grupo.id, evento_id=evento.id)

        else:
            divisao_form = DivisaoForm(request.POST, grupo_id=grupo.id)
            if divisao_form.is_valid():
                divisao_form.save()
                messages.success(request, 'Divisão salva com sucesso!')
                return redirect('editar_divisoes', grupo_id=grupo.id, evento_id=evento.id)

    return render(request, 'html/editar_divisoes.html', {
        'grupo': grupo,
        'evento': evento,
        'divisoes': divisoes,
        'modalidades': modalidades,
        'divisao_form': divisao_form,
        'data_hoje': data_hoje
    })


@login_required(login_url='login')
def criar_evento(request):
    if not is_admin_esportivo(request.user):
        return redirect('home')
    if request.method == 'POST':
        form = EdicaoEventoForm(request.POST)
        if form.is_valid():
            evento_data = form.cleaned_data
            evento_original = evento_data['evento_original']
            novo_evento_original = evento_data['novo_evento_original']
            
            if not evento_original:
                evento_original = EventoOriginal.objects.create(nome=novo_evento_original)
            
            edicao_evento = EdicaoEvento.objects.create(
                edicao=form.cleaned_data['edicao'],
                local=form.cleaned_data['local'],
                descricao=form.cleaned_data['descricao'],
                cidade=form.cleaned_data['cidade'],
                data_inicio=form.cleaned_data['data_inicio'],
                data_fim=form.cleaned_data['data_fim'],
                data_fim_inscricao=form.cleaned_data['data_fim_inscricao'],
                evento_original=evento_original
            )
            
            evento_folder = os.path.join(settings.MEDIA_ROOT, 'eventos', str(edicao_evento.edicao))
            if not os.path.exists(evento_folder):
                os.makedirs(evento_folder)

            num_grupos = int(request.POST.get('num_grupos', 0))
            for i in range(num_grupos):
                grupo_nome = request.POST.get(f'grupo_nome_{i}')
                grupo_descricao = request.POST.get(f'grupo_descricao_{i}')
                grupo_taxa = request.POST.get(f'grupo_taxa_{i}')
                if grupo_nome:
                    Grupo.objects.create(
                        nome=grupo_nome,
                        descricao_grupo=grupo_descricao,
                        taxa=grupo_taxa,
                        edicao_evento=edicao_evento
                    )
            
            request.session['edicao_evento_id'] = edicao_evento.id
            return redirect('adm')
    else:
        form = EdicaoEventoForm()
    
    return render(request, 'html/criar_evento.html', {'form': form})



def logout_view(request):
    logout(request)
    return redirect('home')

def registro_representante(request):
    if request.method == 'POST':
        form = RepresentanteRegistroForm(request.POST, request.FILES)
        if form.is_valid():
            try:
                representante = form.save()  
                group = Group.objects.get(name='Representante Esportivo')
                representante.user.groups.add(group) 
                return redirect('login')
            except Exception as e:
                print(f"Erro ao salvar representante: {e}") 
        else:
            print(form.errors)  
    else:
        form = RepresentanteRegistroForm()
    
    return render(request, 'html/registro.html', {'form': form})

def login_representante(request):
  if request.method == 'POST':
    form = RepresentanteLoginForm(data=request.POST)
    if form.is_valid():
      username = form.cleaned_data['username']
      password = form.cleaned_data['password']
      user = authenticate(username=username, password=password)
      if user is not None:
            login(request, user)
            return redirect('gerenciar')  
      else:
        form.add_error(None, 'CPF ou senha inválidos.')
  else:
    form = RepresentanteLoginForm()
  return render(request, 'html/login.html', {'form': form})

def download_document(request):
    file_path = 'media/documento/REPRESENTANTE_ESPORTIVO.pdf'
    return FileResponse(open(file_path, 'rb'), as_attachment=True, filename='Termo de Compromisso.pdf')

logger = logging.getLogger(__name__)

def is_admin_esportivo(user):
    return user.groups.filter(name='Administrador Esportivo').exists()

def is_representante_esportivo(user):
    return user.groups.filter(name='Representante Esportivo').exists()

@login_required(login_url='login')
def user(request):
    if not is_representante_esportivo(request.user):
        return redirect('home')
    eventos = EdicaoEvento.objects.all()
    
    context = {
        'eventos': eventos,
    }
    return render(request, 'html/user.html', context)
    

@login_required(login_url='login')
def adm(request): 
    if not is_admin_esportivo(request.user):
        return redirect('user')
    
    eventos = EdicaoEvento.objects.all()
    
    return render(request, 'html/adm.html', {'eventos': eventos})

@login_required(login_url='login')
def eventos_view(request):
    if not is_admin_esportivo(request.user):
        return redirect("home")
    
    if request.method == 'POST':
        form = EdicaoEventoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('html/eventos_view')  
    else:
        form = EdicaoEventoForm()
    
    eventos = EdicaoEvento.objects.all()
    return render(request, 'html/eventos.html', {'form': form, 'eventos': eventos})


def home(request):
    noticias = Noticia.objects.filter(data_fim__gt=timezone.now())
    noticias = Noticia.objects.all().order_by('-criado_em')
    return render(request, 'html/home.html', {'noticias': noticias})


def sobre(request):
    return render(request, 'html/sobre.html')


def editais(request):
    eventos_path = os.path.join(settings.MEDIA_ROOT, 'eventos')

    eventos = []
    if os.path.exists(eventos_path):
        for nome_evento in sorted(os.listdir(eventos_path), key=lambda x: os.path.getmtime(os.path.join(eventos_path, x)), reverse=True):
            evento_path = os.path.join(eventos_path, nome_evento)

            if os.path.isdir(evento_path):
                editais = sorted(
                    [edital for edital in os.listdir(evento_path) if os.path.isfile(os.path.join(evento_path, edital))],
                    key=lambda x: os.path.getmtime(os.path.join(evento_path, x)),
                    reverse=True
                )

                eventos.append({
                    'nome': nome_evento,
                    'editais': [
                        {
                            'nome': edital,
                            'url': os.path.join(settings.MEDIA_URL, 'eventos', nome_evento, edital)
                        }
                        for edital in editais
                    ],
                })

    return render(request, 'html/editais.html', {'eventos': eventos})


   

@login_required(login_url='login')
def noticias(request):
    if not is_admin_esportivo(request.user):
        return redirect('home')
    if request.method == 'POST':
        form = NoticiaForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('home')  
    else:
        form = NoticiaForm()
    return render(request, 'html/noticias.html', {'form': form})



@login_required(login_url='login')
def gerenciar(request):
     if not is_representante_esportivo(request.user):
        return redirect('adm')
        
     return redirect('user')