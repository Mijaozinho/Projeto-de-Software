from efipay import EfiPay
from .credenciais import CREDENTIALS

gn = EfiPay(CREDENTIALS)


def verifica_status(txid):
    params = {
        'txid': txid
    }

    response =  gn.pix_detail_charge(params=params)
    status = response['status']
    if status == "ATIVA":
        status = "AGUARDANDO PAGAMENTO"
    return status