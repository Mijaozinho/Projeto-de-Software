from efipay import EfiPay
from .credenciais import CREDENTIALS
from datetime import datetime


efi = EfiPay(CREDENTIALS)
def calcular_segundos_ate_data(future_date_str):
    formato = "%d/%m/%y"
    future_date = datetime.strptime(future_date_str, formato)
    
    now = datetime.now()
    difference = future_date - now
    

    return int(difference.total_seconds())



def pagar_pix(data_final, taxa, numero_atletas, cpf, nome):
    valor = ((taxa)*numero_atletas)
    print(valor)
    cpf = str(cpf)
    valor_formatado = str(valor)  
    segundos = calcular_segundos_ate_data(data_final)
    body = {
        'calendario': {
            'expiracao': int(segundos)
        },
        'devedor': {
            'cpf': cpf,
            'nome': nome
        },
        'valor': {
            'original': valor_formatado
        },
        'chave': '44ee453e-c14d-40c5-b7fd-8cca0bf55c70',
        'solicitacaoPagador':'Valor referente ao numero de atletas'
    }

    response = efi.pix_create_immediate_charge(body=body)
    print(response)
    idPix = response['txid']
    status = response['status']
    loc_id = response["loc"]["id"]
    params = {
        'id': response['loc']['id']
    }
    response = efi.pix_generate_qrcode(params=params)

    linkPix = response["linkVisualizacao"]
    
    
    dados_pix=[linkPix, idPix]

    return dados_pix

