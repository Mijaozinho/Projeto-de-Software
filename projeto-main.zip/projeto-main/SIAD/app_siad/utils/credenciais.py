import os

CREDENTIALS = {
}
