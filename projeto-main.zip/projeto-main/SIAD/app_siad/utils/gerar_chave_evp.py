from gerar_cobranca_pix import verificaPagamento, idPix

verificaPagamento(idPix)