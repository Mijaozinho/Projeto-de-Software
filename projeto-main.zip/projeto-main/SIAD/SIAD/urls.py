
from django.contrib import admin
from django.urls import path, include
from app_siad import views
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth import views as auth_views  

urlpatterns = [
    path('download/', views.download_document, name='download_document'),
    path('admin/', admin.site.urls),
    path('',views.home, name="home"),
    path('editais/',views.editais, name="editais"),
    path('sobre/',views.sobre, name="sobre"),
    path('adm/', views.adm, name='adm'),
    path('user/', views.user, name="user"),
    path('logout/', views.logout_view, name='logout'),
    path('login/', views.login_representante, name='login'),
    path('cadastro/', views.registro_representante, name='cadastro'),
    path('eventos/', views.eventos_view, name='eventos_view'),
    path('tinymce/', include('tinymce.urls')),
    path('criar-evento/', views.criar_evento, name='criar_evento'),
    path('grupo/<int:evento_id>/<int:grupo_id>/', views.detalhes_grupo, name='detalhes_grupo'),
    path('detalhes_user/<int:evento_id>/<int:grupo_id>/', views.detalhes_user, name='detalhes_user'),
    path('upload_edital/<int:evento_id>/', views.upload_edital, name='upload_edital'),
    path('detalhes_evento/<int:evento_id>/', views.evento_detalhes, name='detalhes_evento'),
    path('noticias/', views.noticias, name='noticias'),
    path('gerenciar/', views.gerenciar, name='gerenciar'),
    path('editar_divisoes/<int:evento_id>/<int:grupo_id>/', views.editar_divisoes, name="editar_divisoes" ),
    path('evento/<int:evento_id>/excluir_evento/', views.excluir_evento, name='excluir_evento'),
    path('inscricao/<int:evento_id>/<int:grupo_id>/', views.inscricao, name="inscricao"),
    path('inscrever_divisoes/<int:evento_id>/<int:grupo_id>/', views.inscrever_divisoes, name="inscrever_divisoes"),
    path('evento/<int:evento_id>/grupo/<int:grupo_id>/divisao/<int:divisao_id>/inscricao/', views.divisao_page, name='divisao_page'),
    path('evento/<int:evento_id>/grupo/<int:grupo_id>/divisao_adm/<int:divisao_id>/', views.divisao_adm, name="divisao_adm"),
    path('evento/<int:evento_id>/grupo/<int:grupo_id>/divisao/<int:divisao_id>/equipe/<int:equipe_id>/atletas/', views.listar_atletas, name='listar_atletas'),
    path('evento/<int:evento_id>/grupo/<int:grupo_id>/divisao/<int:divisao_id>/representante/excluir/', views.excluir_representacoes_selecionadas, name='excluir_representacoes_selecionadas'),
    path('processar_pagamento/<int:id_grupo>/<str:nome>/<str:cpf>/<int:id_evento>/', views.processar_pagamento, name='processar_pagamento'),
    path('password_reset/', auth_views.PasswordResetView.as_view(), name='password_reset'),
    path('password_reset_done/', auth_views.PasswordResetDoneView.as_view(), name='password_reset_done'),
    path('reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(), name='password_reset_confirm'),
    path('password_reset_complete/', auth_views.PasswordResetCompleteView.as_view(), name='password_reset_complete'),
    path('evento/<int:evento_id>/grupo/<int:grupo_id>/gerar-pdf/', views.gerar_pdf, name='gerar_pdf'),
    path('evento/<int:evento_id>/grupo/<int:grupo_id>/gerar-csv/', views.gerar_csv, name='gerar_csv'),

]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

